//
// "$Id: CollapsibleWindow.cxx 17 2005-12-17 04:00:11Z mike $"
//
//   Collapsible window widget definitions.
//
//   Copyright 2005 by Michael R Sweet, All Rights Reserved.
//
// Contents:
//
//   CollapsibleWindow::CollapsibleWindow()  - Create a collapsible window.
//   CollapsibleWindow::CollapsibleWindow()  - Create a collapsible window at
//                                             a location.
//   CollapsibleWindow::~CollapsibleWindow() - Destroy a collapsible window.
//   CollapsibleWindow::draw()               - Redraw a collapsible window.
//   CollapsibleWindow::draw_pane()          - Draw a single child/pane.
//   CollapsibleWindow::handle()             - Handle events in a collapsible
//                                             window.
//   CollapsibleWindow::handle_pane()        - Handle clicks in a single
//                                             child/pane.
//   CollapsibleWindow::timeout_cb()         - Image animation timeout.
//

#include "CollapsibleWindow.h"
#include <FL/Fl.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Image.H>
#include <stdio.h>


//
// 'CollapsibleWindow::CollapsibleWindow()' - Create a collapsible window.
//

CollapsibleWindow::CollapsibleWindow(
    int        W,			// I - Width
    int        H,			// I - Height
    const char *L)			// I - Label (window title)
  : Fl_Double_Window(W, H, L)
{
  button_color(FL_DARK1);
  button_ = 0;
  show_deimage_ = false;
  timer_started_ = false;
}


//
// 'CollapsibleWindow::CollapsibleWindow()' - Create a collapsible window at a location.
//

CollapsibleWindow::CollapsibleWindow(
    int        X,			// I - X position
    int        Y,			// I - Y position
    int        W,			// I - Width
    int        H,			// I - Height
    const char *L)			// I - Label (window title)
  : Fl_Double_Window(X, Y, W, H, L)
{
  button_color(FL_GRAY);
  selection_color(FL_LIGHT2);
  button_ = 0;
  show_deimage_ = false;
  timer_started_ = false;
}


//
// 'CollapsibleWindow::~CollapsibleWindow()' - Destroy a collapsible window.
//

CollapsibleWindow::~CollapsibleWindow()
{
  if (timer_started_)
    Fl::remove_timeout(timeout_cb, this);
}


//
// 'CollapsibleWindow::draw()' - Redraw a collapsible window.
//

void
CollapsibleWindow::draw()
{
  int		i,			// Looping var
		Y;			// Y position


  if (!shown())
    return;

  if (damage() & FL_DAMAGE_ALL)
  {
    if (image())
      image()->draw(0, 0, w(), h());
    else
    {
      fl_color(color());
      fl_rectf(0, 0, w(), h());
    }
  }

  for (i = 0, Y = 0; i < children(); i ++)
    draw_pane(Y, child(i));

  if (Y != h())
    resize(x(), y(), w(), Y);
}


//
// 'CollapsibleWindow::draw_pane()' - Draw a single child/pane.
//

void
CollapsibleWindow::draw_pane(
    int       &Y,			// IO - Y position
    Fl_Widget *wi)			// I  - Group/child widget
{
  int		LX, LW;			// Label position/width
  int		H;			// Pane height
  const char	*L;			// Group label
  Fl_Color	c;			// Button color


  if (wi->label())
  {
    fl_font(labelfont(), labelsize());

    if (damage() & FL_DAMAGE_ALL)
    {
      H = 21;
      if (wi->visible())
        H += wi->h();

      fl_draw_box(FL_RFLAT_BOX, 2, Y + 2, w() - 4, H, c = button_color());

      if (wi == button_)
      {
        fl_push_clip(2, Y + 2, w() - 4, 21);
        fl_draw_box(FL_RFLAT_BOX, 2, Y + 2, w() - 4, H,
	            c = selection_color());
	fl_pop_clip();
      }

      LX = 25;
      LW = w() - 25;

      if (wi->image())
      {
	fl_color(fl_contrast(labelcolor(), c));

        if (wi->deimage() && wi->image() != wi->deimage() && !timer_started_)
	{
          Fl::add_timeout(0.25, timeout_cb, this);
	  timer_started_ = true;
	}

        if (show_deimage_ && wi->deimage())
	{
	  LW -= wi->deimage()->w() + 5;
          wi->deimage()->draw(LX + LW, Y + (25 - wi->deimage()->h()) / 2);
        }
	else
	{
	  LW -= wi->image()->w() + 5;
          wi->image()->draw(LX + LW, Y + (25 - wi->image()->h()) / 2);
        }
      }

      fl_color(fl_contrast(labelcolor(), c));

      fl_draw_shortcut = 1;
      fl_draw(wi->label(), LX, Y, LW, 25,
              (Fl_Align)(FL_ALIGN_INSIDE | FL_ALIGN_LEFT));
      fl_draw_shortcut = 0;

      fl_color(fl_color_average(fl_color(), c, 0.5f));

      if (wi->visible())
	fl_polygon(10, Y + 7, 20, Y + 7, 15, Y + 17);
      else
	fl_polygon(10, Y + 7, 20, Y + 12, 10, Y + 17);
    }

    Y += 25;
  }

  if (wi->visible())
  {
    if (wi->y() != Y)
      wi->position(0, Y);

    Y += wi->h();

    L = wi->label();
    wi->label(0);
    draw_child(*wi);
    wi->label(L);
  }
}


//
// 'CollapsibleWindow::handle()' - Handle events in a collapsible window.
//

int					// O - 1 = handled event
CollapsibleWindow::handle(int event)	// I - Event
{
  int	ii,				// Looping var
	Y,				// Y position
	status;				// Return status


  if (event == FL_PUSH || event == FL_RELEASE || event == FL_DRAG ||
      event == FL_MOVE || event == FL_SHORTCUT)
  {
    for (ii = 0, Y = 0, status = 0; ii < children(); ii ++)
      status |= handle_pane(event, Y, child(ii));

    if (status)
      return (1);
  }
  else if (event == FL_ENTER || event == FL_LEAVE)
    return (1);

  return (Fl_Double_Window::handle(event));
}


//
// 'CollapsibleWindow::handle_pane()' - Handle clicks in a single child/pane.
//

int					// O  - 1 = handled event
CollapsibleWindow::handle_pane(
    int       event,			// I  - Event
    int       &Y,			// IO - Y position
    Fl_Widget *wi)			// I  - Group/child widget
{
  int	status;				// Status to return...
  int	H;				// Height of window


  status = 0;

  if (!wi->label())
  {
    if (wi->visible())
      Y += wi->h();

    return (0);
  }

  if ((Fl::event_y() >= (Y + 2) && Fl::event_y() < (Y + 23) &&
       event != FL_SHORTCUT) ||
      Fl_Widget::test_shortcut(wi->label()))
  {
    status = 1;

    if (event == FL_RELEASE || event == FL_SHORTCUT)
    {
      if (button_)
      {
        redraw();
        button_ = 0;
      }

      if (wi->visible())
      {
        wi->hide();
	H = h() - wi->h() - 25;
      }
      else
      {
        wi->show();

	H = h() + wi->h();
      }

      resize(x(), y(), w(), H);
    }
    else
    {
      button_ = wi;
      redraw();
    }
  }
  else if (button_ == wi)
  {
    button_ = 0;
    redraw();
  }

  Y += 25;

  if (wi->visible())
    Y += wi->h();

  return (status);
}


//
// 'CollapsibleWindow::timeout_cb()' - Image animation timeout.
//

void
CollapsibleWindow::timeout_cb(
    void *data)				// I - Callback data
{
  CollapsibleWindow	*c;		// Collapse widget
  int			i;		// Looping var
  Fl_Widget		*wi;		// Current widget


  c                 = (CollapsibleWindow *)data;
  c->show_deimage_  = !c->show_deimage_;
  c->timer_started_ = false;

  for (i = 0; i < c->children(); i ++)
  {
    wi = c->child(i);

    if (wi->image() && wi->deimage() && wi->image() != wi->deimage())
    {
      c->damage(FL_DAMAGE_ALL, 0, wi->y() - 25, c->w(), 25);

      if (!c->timer_started_)
      {
	Fl::repeat_timeout(0.25, timeout_cb, c);
	c->timer_started_ = true;
      }
    }
  }
}


//
// End of "$Id: CollapsibleWindow.cxx 17 2005-12-17 04:00:11Z mike $".
//
