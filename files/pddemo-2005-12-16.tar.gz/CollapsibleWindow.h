//
// "$Id: CollapsibleWindow.h 16 2005-12-16 23:36:43Z mike $"
//
//   Collapsible window widget definitions.
//
//   Copyright 2005 by Michael R Sweet, All Rights Reserved.
//

#ifndef _CollapsibleWindow_h_
#  define _CollapsibleWindow_h_
#  include <FL/Fl_Double_Window.H>


class CollapsibleWindow : public Fl_Double_Window
{
  Fl_Color	button_color_;
  Fl_Widget	*button_;
  bool		show_deimage_;
  bool		timer_started_;

  void draw_pane(int &Y, Fl_Widget *wi);
  int handle_pane(int event, int &Y, Fl_Widget *wi);
  static void timeout_cb(void *data);

  public:

  CollapsibleWindow(int W, int H, const char *L = 0);
  CollapsibleWindow(int X, int Y, int W, int H, const char *L = 0);
  ~CollapsibleWindow();

  Fl_Color button_color() const { return (button_color_); }
  void button_color(Fl_Color c) { button_color_ = c; }

  virtual void draw();
  virtual int handle(int event);
};

#endif // !_CollapsibleWindow_h_


//
// End of "$Id: CollapsibleWindow.h 16 2005-12-16 23:36:43Z mike $".
//
