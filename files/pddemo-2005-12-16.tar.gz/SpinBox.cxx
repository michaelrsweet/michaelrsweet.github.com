//
// "$Id: SpinBox.cxx 15 2005-12-15 03:19:16Z mike $"
//
//   Spinbox widget code for ESP Print Pro.
//
//   Copyright 2003-2005 by Michael R Sweet, All Rights Reserved.
//
// Contents:
//
//   SpinBox::callback() - Handle changes in the spinbox.
//   SpinBox::update()   - Update the value of the spinbox.
//   SpinBox::SpinBox()  - Create a spinbox widget.
//

//
// Include necessary headers...
//

#include "SpinBox.h"
#include <stdio.h>
#include <stdlib.h>


//
// 'SpinBox::sb_cb()' - Handle changes in the spinbox.
//

void
SpinBox::sb_cb(Fl_Widget *w,		// I - Widget
               SpinBox   *sb)		// I - Spinbox
{
  int	v;				// New value


  if (w == &(sb->input_))
  {
    // Something changed in the input field...
    v = atoi(sb->input_.value());

    if (v < sb->minimum_)
    {
      sb->value_ = sb->minimum_;
      sb->update();
    }
    else if (v > sb->maximum_)
    {
      sb->value_ = sb->maximum_;
      sb->update();
    }
    else
      sb->value_ = v;
  }
  else if (w == &(sb->up_button_))
  {
    // Up button pressed...
    v = sb->value_ + sb->step_;

    if (v > sb->maximum_)
      sb->value_ = sb->minimum_;
    else
      sb->value_ = v;

    sb->update();
  }
  else if (w == &(sb->down_button_))
  {
    // Down button pressed...
    v = sb->value_ - sb->step_;

    if (v < sb->minimum_)
      sb->value_ = sb->maximum_;
    else
      sb->value_ = v;

    sb->update();
  }

  sb->do_callback();
}


//
// 'SpinBox::update()' - Update the value of the spinbox.
//

void
SpinBox::update()
{
  char	s[255];				// Value string


  sprintf(s, format_, value_);
  input_.value(s);
}


//
// 'SpinBox::SpinBox()' - Create a spinbox widget.
//

SpinBox::SpinBox(int        X,		// I - X position
                 int        Y,		// I - Y position
		 int        W,		// I - Width
		 int        H,		// I - Height
		 const char *L)		// I - Label
  : Fl_Group(X, Y, W, H, L),
    input_(X, Y, W - H / 2 - 2, H),
    up_button_(X + W - H / 2 - 2, Y, H / 2 + 2, H / 2, "@-22<"),
    down_button_(X + W - H / 2 - 2, Y + H - H / 2, H / 2 + 2, H / 2, "@-22>")
{
  end();

  value_   = 0;
  minimum_ = 0;
  maximum_ = 100;
  step_    = 1;
  format_  = "%d";

  align(FL_ALIGN_LEFT);

  input_.value("0");
  input_.type(FL_INT_INPUT);
  input_.when(FL_WHEN_CHANGED);
  input_.callback((Fl_Callback *)sb_cb, this);

  up_button_.callback((Fl_Callback *)sb_cb, this);

  down_button_.callback((Fl_Callback *)sb_cb, this);
}


//
// End of "$Id: SpinBox.cxx 15 2005-12-15 03:19:16Z mike $".
//
