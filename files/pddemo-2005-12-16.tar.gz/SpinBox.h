//
// "$Id: SpinBox.h 15 2005-12-15 03:19:16Z mike $"
//
//   Spinbox widget definitions.
//
//   Copyright 2003-2005 by Michael R Sweet, All Rights Reserved.
//

#ifndef _SpinBox_h_
#  define _SpinBox_h_

//
// Include necessary headers...
//

#  include <FL/Fl_Group.H>
#  include <FL/Fl_Input.H>
#  include <FL/Fl_Repeat_Button.H>


//
// SpinBox widget class...
//

class SpinBox : public Fl_Group
{
  int		value_;			// Current value
  int		minimum_;		// Minimum value
  int		maximum_;		// Maximum value
  int		step_;			// Amount to add/subtract for up/down
  const char	*format_;		// Format string

  Fl_Input	input_;			// Input field for the value
  Fl_Repeat_Button
		up_button_,		// Up button
		down_button_;		// Down button

  static void	sb_cb(Fl_Widget *w, SpinBox *sb);
  void		update();

  public:

		SpinBox(int X, int Y, int W, int H, const char *L = 0);

  const char	*format() { return (format_); }
  void		format(const char *f) { format_ = f; update(); }
  int		maxinum() const { return (maximum_); }
  void		maximum(int m) { maximum_ = m; }
  int		mininum() const { return (minimum_); }
  void		minimum(int m) { minimum_ = m; }
  void		range(int a, int b) { minimum_ = a; maximum_ = b; }
  int		step() const { return (step_); }
  void		step(int s) { step_ = s; }
  int		value() const { return (value_); }
  void		value(int v) { value_ = v; update(); }
};

#endif // !_SpinBox_h_

//
// End of "$Id: SpinBox.h 15 2005-12-15 03:19:16Z mike $".
//
