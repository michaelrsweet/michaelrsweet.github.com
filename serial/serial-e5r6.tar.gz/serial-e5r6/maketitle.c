/*
 * "$Id: maketitle.c,v 1.1 2003/03/11 13:24:11 mike Exp $"
 *
 * Generate a PGM image of the serial guide title string.
 *
 * Copyright 1994-2003 by Michael Sweet, All Rights Reserved.
 *
 * Contents:
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*
 * Output image buffer and width of each bit...
 */

#define WIDTH 760

unsigned char	pixels[40][WIDTH];
int		bitwidth;


/*
 * Prototypes...
 */

void	render_string(const char *s, int slen, int y);


/*
 * 'main()' - Main entry for the program.
 */

int						/* O - Exit status */
main(int  argc,					/* I - Number of command-line args */
     char *argv[])				/* I - Command-line args */
{
  int	slen,					/* Total length of string */
	swidth;					/* 1/3 of string */


 /*
  * Verify command-line args...
  */

  if (argc != 2)
  {
    fputs("Usage: maketitle \"title string\" > title.pgm\n", stderr);
    return (1);
  }

 /*
  * Clear the image...
  */

  memset(pixels, 255, sizeof(pixels));

 /*
  * Render the string on three lines...
  */

  slen     = strlen(argv[1]);
  swidth   = (slen + 2) / 3;
  bitwidth = (WIDTH - 40) / 10 / swidth;

  fprintf(stderr, "swidth = %d, bitwidth = %d\n", swidth, bitwidth);

  if (bitwidth < 2)
  {
    fputs("maketitle: Title string too long!\n", stderr);
    return (1);
  }

  render_string(argv[1], swidth, 4);
  render_string(argv[1] + swidth, swidth, 16);
  render_string(argv[1] + 2 * swidth, slen - 2 * swidth, 28);

 /*
  * Write the image...
  */

  puts("P5");
  printf("%d 40 255\n", WIDTH);
  fwrite(pixels, 1, sizeof(pixels), stdout);

  return (0);
}


/*
 * 'render_string()' - Render a string as serial bits.
 */

void
render_string(const char *s,			/* I - String to render */
              int        slen,			/* I - Number of characters */
              int        y)			/* I - Position in image */
{
  int	bit,					/* Current bit */
	lastbit,				/* Previous bit */
	parity;					/* Parity value */
  int	i,					/* Looping var */
	x;					/* Current X coordinate */
  int	width,					/* Total width of string */
	leader;					/* Leading pixels */


 /*
  * Compute the pixel width and leader/trailer length...
  */

  width  = slen * 10 * bitwidth;
  leader = (WIDTH - width) / 2;

 /*
  * Output the leader line...
  */

  memset(pixels[y + 7], 0, leader);

 /*
  * Now the string bits...
  */

  for (x = leader; slen > 0; s ++, slen --)
  {
    for (i = 1; i < 8; i ++)
      pixels[y + i][x] = 0;

    memset(pixels[y] + x, 0, bitwidth);
    lastbit = 0;
    x += bitwidth;

    for (bit = 1, parity = 0; bit < 128; bit *= 2, x += bitwidth)
    {
      if ((lastbit != 0) != ((*s & bit) != 0))
        for (i = 0; i < 8; i ++)
	  pixels[y + i][x] = 0;

      if (*s & bit)
      {
        memset(pixels[y + 7] + x, 0, bitwidth);
	parity ++;
	lastbit = 1;
      }
      else
      {
        memset(pixels[y] + x, 0, bitwidth);
	lastbit = 0;
      }
    }

    bit = parity & 1;

    if ((lastbit != 0) != ((bit) != 0))
      for (i = 0; i < 8; i ++)
        pixels[y + i][x] = 0;

    if (bit)
    {
      memset(pixels[y + 7] + x, 0, 2 * bitwidth);
      parity ++;
    }
    else
    {
      memset(pixels[y] + x, 0, bitwidth);
      for (i = 0; i < 8; i ++)
        pixels[y + i][x + bitwidth] = 0;
      memset(pixels[y + 7] + x + bitwidth, 0, bitwidth);
    }

    x += 2 * bitwidth;
  }

 /*
  * Finally the trailer line...
  */

  memset(pixels[y + 7] + x, 0, leader);
}


/*
 * End of "$Id: maketitle.c,v 1.1 2003/03/11 13:24:11 mike Exp $".
 */
